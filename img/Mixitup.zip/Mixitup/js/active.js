(function ($) {
"use strict";

/*--------------------------------------
	mixitup Active
----------------------------------------*/
var mixer = mixitup('.portfolio-item',{
	animation:{
		effectsOut:'fade translateX(-100%)',
	}
});


})(jQuery);	